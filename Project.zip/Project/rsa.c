#include<stdio.h>
#include<conio.h>
#include<string.h>

struct Pkey{
char hostname[40];
long int publickey;
long int privatekey;
};

void main()
{
long int p,q,n,fn,e,s=0,d=1,C[100],M;
char m[100],str[80], ignore;
long int cipher[80];
//char [40] host;
unsigned long int b=0,c=0;
int i,j,t,k,flag,temp;
FILE *fp;
int rand1,rand2;
int array[59]={ 2  ,    3,      5,      7,     11,     13,     17,     19,     23,     29, 
     31,     37,     41,     43,     47,     53,     59,     61,     67,     71, 
     73 ,    79,     83,     89,     97,    101,    103,    107,    109,    113, 
    127  ,  131,    137,    139,    149,    151,    157,    163,    167,    173, 
    179   , 181,    191,    193,    197,    199,    211,    223,    227,    229, 
    233    ,239,    241,    251,    257,    263,    269,    271,    277};
	
srand(time(0));
i = rand() % 59;
p = array[i]; // choose random prime number 1
j = 1 + rand() % (59 - 2);
q = array[(i + j) % 59];  // choose random prime number 2

n=p*q;
fn=(p-1)*(q-1);
do{
k= 2+rand() % (59-3);
e=array[(i+j+k) % 59]; // choose e at random that's not a relative prime with fn i.e.,((p-1)(q-1))
flag=hcf(e,fn);
break;
}while(flag=1 && e<n );

do
{ s=(d*e)%fn;
d++;
}while(s!=1);
d=d-1;
struct Pkey* serverPkey;
serverPkey=(char *)malloc(sizeof(struct Pkey));
char host[]="samsung-pc";
strcpy(serverPkey->hostname,host);
//serverPkey->hostname="samsung-pc";
serverPkey->publickey=e;
serverPkey->privatekey=d;

printf("\n\nEnter message :\n");
//scanf("%s",str);
scanf("%79[^\n]%c", str, &ignore);
for(j=0;j< strlen(str);j++)
{
t=(int)str[j];
c=1;
for(i=0;i< e;i++){
c=c*t%n;
c=c%n;
}
printf("%d ",c);
cipher[j]=c;
}
for(i=0;i< strlen(str);i++)
C[i]=cipher[i];
printf("\n\n\tPlaintext :");

for(j=0;j< strlen(str);j++)
{
M=1;
for(i=0;i< d;i++)
M=M*C[j]%n;
M=M%n;
printf("%c",M);
}
getch();
}

int hcf(int a, int h) 
{
    int temp; 
    while(1)
    {
        temp = a%h;
        if(temp==0)
        return h;
        a = h;
        h = temp;
    }
} 

